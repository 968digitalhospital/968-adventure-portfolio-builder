---
name: 968-adventure-portfolio-builder
description: Build or evolve a premium personal adventure portfolio website that combines amateur radio, drone photography, fine-art print sales, 4x4 overlanding, and community/service storytelling. Use when creating or updating a similar multi-hobby portfolio, especially when user-provided photos, watermarked galleries, expedition journals, or iterative WebDev edits are involved.
---

# 968 Adventure Portfolio Builder

## Overview

Use this skill to turn a personal, multi-disciplinary identity into a cohesive, cinematic portfolio website. The default expression is a field-journal aesthetic: deep navy, sand, signal orange, editorial serif headlines, compact mono labels, generous whitespace, subtle grain, and restrained motion.

## Workflow

1. **Understand the person and the site job.** Identify the core disciplines, location, credentials, equipment, audience, desired action, and whether the site is a portfolio, print storefront, journal, or service profile. Never invent personal equipment, certifications, prices, dates, or experiences; use clearly labeled placeholders only when the user agrees.
2. **Research visual references.** For requests that mention searching the web, use the web-research route and gather references for landscapes, field operations, and editorial photography. Prefer original or user-provided assets in the final website; do not copy third-party images into a commercial gallery without permission.
3. **Choose the visual system.** Declare a specific design direction before coding. Pair a display serif with a readable sans and mono metadata. Use an asymmetric editorial layout instead of generic centered cards. Design dark hero and field sections against warm paper/sand content sections.
4. **Initialize the WebDev project.** For a portfolio or static storefront, use the WebDev `web-static` scaffold. Read the static WebDev guidance first. Keep media outside `client/public` and `client/src/assets`; upload final assets with `manus-upload-file --webdev` and reference the returned `/manus-storage/...` path. If the user provides a generic radio-dashboard template, merge its useful content into the existing design rather than replacing the visual system.
5. **Create or ingest visual assets.** Generate original hero/section visuals when the user has no assets. When a user supplies a portrait, vehicle, shack, or expedition photo, upload it and use it as the primary visual in the corresponding section. Preserve identity and the important objects in image edits.
6. **Compose the information architecture.** A strong default order is:
   - hero: location, one-line thesis, call sign/credential stats;
   - story: 3–4 pillars such as Signal, Frame, Range, Service;
   - drone field notes: experience, kit, workflow, landscape philosophy;
   - station operations: radio modes, QSL information, shack equipment;
   - 4x4 range: vehicle, modifications, recovery, rescue, convoy ethos;
   - route journal: dated expeditions and incidents;
   - print room: watermarked preview, title, location/category, edition, price, request CTA;
   - contact/community close.
   For an amateur-radio-focused companion page, add a separate callsign route such as `/a41da` with a dark console hero, operating-focus cards, Station/Shack inventory, QSL information, live-widget placeholders, and a `73 de A41DA` footer. Link to it from the primary portfolio navigation.
7. **Protect preview images honestly.** Add visible coordinate/call-sign watermark overlays, low-resolution preview language, `draggable=false`, image drag prevention, and a context-menu deterrent. State clearly that front-end deterrents cannot prevent screenshots, screen photography, or developer-tools access. For real protection, propose authenticated/server-side delivery and signed URLs.
8. **Use real interactions.** Include anchor navigation, mobile menu, gallery filtering, carousel controls, request-print feedback, and keyboard-reachable buttons. Use `sonner` for staged actions. Keep payment or licensing flows as a clear request/placeholder unless a backend/payment integration is actually enabled.
9. **Add user-supplied details in structured form.** For equipment, show model, role/specification, and upgrade date only when known. For route journals, show date/status, route or region, objective, conditions, recovery lesson, and photo. For uncertain facts, use “Add details” or an editable data structure rather than guessing.
10. **Validate before delivery.** Run `pnpm check` and `pnpm build`. Capture a desktop and mobile preview; use a full-page capture for long editorial pages. Fix only concrete runtime, content, or layout defects. Save one checkpoint after the feature set is complete and deliver its `manus-webdev://...` link.

## Reusable Content Patterns

### Vehicle modification log

Use an editable array with fields:

```ts
{ category: "Suspension", item: "[user-provided upgrade]", specification: "[spec or purpose]", date: "[YYYY or month YYYY]" }
```

Group entries by suspension, tires/wheels, protection, recovery, communications, navigation, power, and storage. If the user has not supplied a value, display “Details to add” rather than fabricating it.

### Route journal

Use an array with fields:

```ts
{ date: "[date]", route: "[region / expedition]", status: "Expedition" | "Recovery", summary: "[short account]", lesson: "[practical takeaway]", image: "[storage path]" }
```

Make the journal scannable with a vertical timeline or horizontal cards. Include rescue and recovery experiences as operational learning, not as exaggerated claims.

### Image carousel

Implement a controlled carousel with:

- previous/next buttons with accessible labels;
- dot or thumbnail indicators;
- keyboard reachability;
- `aria-live` for the active slide title;
- one large protected image using the same `Watermark` overlay as the print gallery;
- caption, route/date, and a “recovery” or “expedition” tag;
- no autoplay by default; if autoplay is requested, pause on hover/focus and respect reduced motion.

Use the existing shadcn carousel only if it is quicker and remains visually consistent; otherwise use a small local state machine with `useState` and an array of slides.

### Interactive gear list

Represent Jeep and drone equipment as one normalized array with `type`, `name`, `specification`, `role`, and `status` fields. Render compact selectable cards or list rows; clicking one opens an adjacent detail panel or dialog with the full specification. Keep the selected item in React state, expose selection with `aria-pressed` or tabs, and show “Details to add” rather than inventing unprovided model numbers or dates.

### Photography lightbox

Use a controlled `selectedImage` state for gallery and print-room images. Open a full-screen dialog from a keyboard-reachable “View full screen” button, include a large image, title, location, and an explicit close button, and close on Escape. Preserve the visible watermark on previews and explain that high-resolution delivery remains license-controlled; do not expose original source files from a static public folder.

### Route terrain filtering

Add a `terrain` field to every route-journal item, such as `Desert`, `Mountain`, or `Coastal`. Render filter buttons as a single-select tablist with an `All` option, derive visible entries with `useMemo`, and keep the active filter in state. Announce the active result count with `aria-live`; do not mutate the source journal array.

### Station/Shack hardware inventory

Use a structured inventory with `group`, `item`, `role`, and `specification` fields. Include known radios such as the Kenwood TS-2000, Yaesu FT-450D, and any confirmed Anytone/Kenwood VHF/UHF devices. Add antenna, amplifier, feed-line, power, grounding, and backup-power rows. Never infer antenna models, amplifier ratings, or exact radio configurations; write “Details to add” or “Not installed” where needed. Render the inventory as a responsive overflow-safe table with readable column labels.

### Standalone amateur-radio dashboard

Create a dedicated page component rather than a second application. Use a deep charcoal/slate background, warm dune-gold primary accent, cyan secondary accent, and signal-green status indicator. Include four operating cards: HF DXing, Digital Modes (FT8/JS8Call), VHF/UHF, and Satellite Work. Keep QRZ, Club Log, HRDLOG, HamQSL, and N0NBH areas as explicit placeholders until the user supplies approved embed URLs or profile links; external providers may block iframes.

## Quality Guardrails

- Keep the page visually authored: avoid generic dashboard layouts and excessive pills.
- Preserve text contrast over photography with overlays or solid panels.
- Keep animations under 300ms for controls and respect `prefers-reduced-motion`.
- Do not represent generated visuals as the user’s real equipment or expedition evidence.
- Distinguish “ROAR radio shack” from a private home shack when the user corrects the location.
- Do not promise that right-click disabling makes images impossible to copy; describe it as a deterrent.
- Do not edit backend/server code unless the user explicitly asks for secure delivery, authentication, payments, or data persistence; then recommend upgrading from static to a backend-capable scaffold.

## Delivery Checklist

- [ ] User details, credentials, equipment, and locations are accurate.
- [ ] User-provided assets replace placeholders where available.
- [ ] Gallery previews show watermark and price/license context.
- [ ] Carousel and mobile menu work with keyboard-accessible controls.
- [ ] Gear cards expose details through keyboard-reachable controls.
- [ ] Lightbox opens/closes predictably, supports Escape, and preserves watermark context.
- [ ] Route filters use a normalized terrain field and accessible active state.
- [ ] Standalone callsign page has a route, back link, QSL section, and clearly labeled external-widget placeholders.
- [ ] Station inventory distinguishes known equipment from details still requiring confirmation.
- [ ] `pnpm check` passes.
- [ ] `pnpm build` passes.
- [ ] Desktop/mobile/full-page previews are visually checked.
- [ ] Final WebDev checkpoint is saved and linked.
